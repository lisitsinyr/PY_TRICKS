# Changelog

## v1.0.0 - 18.07.2025

Initial release.

### Features
- Video downloads from YouTube and other sites
- Quality selection (144p-4K)
- Audio extraction to MP3
- Download progress tracking
- Cross-platform support

### Technical
- Python 3.9+
- CustomTkinter interface
- Executable builds

# Contributing

## Setup

```bash
git clone https://github.com/vokrob/yt-dlp-gui.git
cd yt-dlp-gui
pip install -r requirements.txt
python main.py
```

## Guidelines

- Test before submitting
- Keep commits focused

## Issues

Include OS, Python version, and steps to reproduce.

headers = {"User-Agent": "Mozilla/5.0"}
for page in range(1, page_limit + 1):
response = requests.get(f"{url}?page={page}",
headers=headers)
soup = BeautifulSoup(response.text, 'html.parser')
orders = soup.select(".order-list-item")
for order in orders:
title = order.select_one(".order-title").text.strip()
price = order.select_one(".order-price").text.strip()
print(f"Заголовок: {title}")
print(f"Цена: {price}\n")
# Пример использования
get_advego_orders("https://advego.com/orders/")
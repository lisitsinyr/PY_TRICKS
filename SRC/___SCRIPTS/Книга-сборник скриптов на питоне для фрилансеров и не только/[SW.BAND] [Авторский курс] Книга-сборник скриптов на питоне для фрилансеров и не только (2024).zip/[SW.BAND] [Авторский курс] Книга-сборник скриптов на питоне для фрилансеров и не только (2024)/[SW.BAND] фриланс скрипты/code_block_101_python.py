Код:
from fpdf import FPDF
import sqlite3
def generate_report_from_db(db_name, output_file):
conn = sqlite3.connect(db_name)
cursor = conn.cursor()
cursor.execute("SELECT * FROM users")
rows = cursor.fetchall()
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)
pdf.cell(200, 10, txt="Отчет пользователей", ln=True,
align='C')
pdf.ln(10)
for row in rows:
pdf.cell(200, 10, txt=f"ID: {row[0]}, Имя: {row[1]}, Email:
{row[2]}", ln=True)
pdf.output(output_file)
print(f"Отчет сохранен в {output_file}")
# Пример использования
generate_report_from_db("users.db", "users_report.pdf")
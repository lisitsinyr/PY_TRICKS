response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')
reviews = soup.select(css_selector)
for i, review in enumerate(reviews, start=1):
print(f"{i}. {review.text.strip()}")
# Пример использования
collect_reviews("https://example.com/reviews", ".review-
text")
import requests
from bs4 import BeautifulSoup
# Пример URL конкурента
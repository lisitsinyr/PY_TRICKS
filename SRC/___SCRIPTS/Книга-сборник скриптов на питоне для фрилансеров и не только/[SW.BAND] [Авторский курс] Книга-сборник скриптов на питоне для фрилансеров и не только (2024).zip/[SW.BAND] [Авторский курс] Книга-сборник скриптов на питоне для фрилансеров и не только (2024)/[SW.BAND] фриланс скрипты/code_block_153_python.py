}
# Отправка запроса
response = requests.get(url, params=params)
if response.status_code == 200:
jobs = response.json()
for job in jobs['data']:
print(f"Заголовок: {job['title']}, Бюджет: {job['budget']}")
else:
print('Ошибка при получении вакансий!')
Код:
import requests
from bs4 import BeautifulSoup
def get_advego_orders(url, page_limit=5):
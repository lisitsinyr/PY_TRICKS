Код:
def download_completed_orders(username, password):
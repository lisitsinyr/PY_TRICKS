Код:
import gspread
from oauth2client.service_account import
with open(file_path, "r") as file:
reader = csv.reader(file)
for row in reader:
transaction_type, amount = row[0], float(row[1])
if transaction_type == "Доход":
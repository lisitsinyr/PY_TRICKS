headers = {"User-Agent": "Mozilla/5.0"}
response = requests.get(url, headers=headers)
soup = BeautifulSoup(response.text, "html.parser")
orders = soup.select(".order")
for order in orders:
title = order.select_one(".order-title").text.strip()
price = order.select_one(".order-price").text.strip()
print(f"Название: {title}")
print(f"Цена: {price}\n")
# Пример использования
get_etxt_orders()
Код:
import requests
def get_projects(api_key):
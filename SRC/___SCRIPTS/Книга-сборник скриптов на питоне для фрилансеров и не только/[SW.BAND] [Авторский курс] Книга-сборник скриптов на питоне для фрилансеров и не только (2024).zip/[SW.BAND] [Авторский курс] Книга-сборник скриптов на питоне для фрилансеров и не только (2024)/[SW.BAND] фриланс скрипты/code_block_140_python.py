Пример мониторинга цен:
import requests
from bs4 import BeautifulSoup
import smtplib
from email.mime.text import MIMEText
# Функция отправки email
def send_email(subject, body):
msg = MIMEText(body)
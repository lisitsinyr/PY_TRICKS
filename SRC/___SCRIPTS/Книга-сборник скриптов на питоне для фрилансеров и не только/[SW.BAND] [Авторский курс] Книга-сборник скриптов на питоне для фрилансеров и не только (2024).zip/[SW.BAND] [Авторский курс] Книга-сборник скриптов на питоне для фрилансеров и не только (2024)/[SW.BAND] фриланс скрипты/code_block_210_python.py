Код:
def check_text_uniqueness_etxt(text):
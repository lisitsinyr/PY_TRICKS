import smtplib
from email.mime.text import MIMEText
def send_email(sender_email, sender_password,
recipient_email, subject, body):
# Формируем письмо
msg = MIMEText(body)
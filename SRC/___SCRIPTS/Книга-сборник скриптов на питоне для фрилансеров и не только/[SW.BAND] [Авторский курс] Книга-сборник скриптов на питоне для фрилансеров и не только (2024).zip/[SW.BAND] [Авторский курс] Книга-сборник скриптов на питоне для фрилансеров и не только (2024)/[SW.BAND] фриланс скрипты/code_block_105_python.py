Код:
from cryptography.fernet import Fernet
def generate_key():
key = Fernet.generate_key()
with open("secret.key", "wb") as key_file:
key_file.write(key)
print("Ключ для шифрования сохранен в 'secret.key'")
def load_key():
with open("secret.key", "rb") as key_file:
return key_file.read()
def encrypt_message(message):
key = load_key()
fernet = Fernet(key)
encrypted = fernet.encrypt(message.encode())
print(f"Зашифрованное сообщение:
{encrypted.decode()}")
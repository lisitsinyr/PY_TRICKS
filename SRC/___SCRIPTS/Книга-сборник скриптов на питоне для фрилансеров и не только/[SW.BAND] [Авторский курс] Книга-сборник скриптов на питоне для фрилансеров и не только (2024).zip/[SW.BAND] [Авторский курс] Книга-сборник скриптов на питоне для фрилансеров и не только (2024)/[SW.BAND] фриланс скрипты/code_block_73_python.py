Код:
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
def send_email_report(sender_email, sender_password,
recipient_email, subject, report_file):
msg = MIMEMultipart()
msg["From"] = sender_email
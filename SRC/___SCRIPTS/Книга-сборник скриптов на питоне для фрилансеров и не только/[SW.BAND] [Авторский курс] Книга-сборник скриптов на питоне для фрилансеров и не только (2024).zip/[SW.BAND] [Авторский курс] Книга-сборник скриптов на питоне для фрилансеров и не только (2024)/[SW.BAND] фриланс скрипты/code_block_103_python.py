Код:
import shutil
def backup_sqlite_database(db_name, backup_file):
shutil.copy(db_name, backup_file)
print(f"Резервная копия базы данных сохранена в
{backup_file}")
def restore_sqlite_database(backup_file, db_name):
shutil.copy(backup_file, db_name)
print(f"База данных восстановлена из {backup_file}")
# Пример использования
backup_sqlite_database("users.db", "users_backup.db")
restore_sqlite_database("users_backup.db",
"users_restored.db")
Код:
import requests
from bs4 import BeautifulSoup
def get_etxt_orders():
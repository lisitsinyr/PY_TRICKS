import pandas as pd
import plotly.express as px
def create_dashboard(file_path):
data = pd.read_excel(file_path)
fig = px.line(data, x="Дата", y="Продажи",
title="Продажи по времени")
fig.show()
# Пример использования
create_dashboard("data.xlsx")
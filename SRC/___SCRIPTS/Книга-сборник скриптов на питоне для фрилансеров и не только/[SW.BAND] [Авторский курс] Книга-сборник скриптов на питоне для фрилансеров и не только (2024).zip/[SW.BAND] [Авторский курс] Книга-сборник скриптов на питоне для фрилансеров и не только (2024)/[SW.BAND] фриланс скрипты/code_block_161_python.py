f"https://www.upwork.com/api/jobs/search?keywords={keyw
ords}"
headers = {"Authorization": f"Bearer {api_key}"}
response = requests.get(url, headers=headers)
if response.status_code == 200:
jobs = response.json()
for job in jobs.get("results", []):
print(f"Название: {job['title']}")
print(f"Описание: {job['snippet']}\n")
else:
print(f"Ошибка: {response.status_code},
{response.text}")
# Пример использования
get_upwork_jobs("your_api_key", "Python Developer")
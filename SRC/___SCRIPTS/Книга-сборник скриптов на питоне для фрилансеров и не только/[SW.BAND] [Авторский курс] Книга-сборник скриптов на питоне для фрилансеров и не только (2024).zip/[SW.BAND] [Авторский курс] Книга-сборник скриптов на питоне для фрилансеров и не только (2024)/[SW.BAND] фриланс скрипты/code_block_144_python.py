if float(price.replace('$', '')) < target_price:
send_email('Цена снизилась!', f'Текущая цена: {price}')
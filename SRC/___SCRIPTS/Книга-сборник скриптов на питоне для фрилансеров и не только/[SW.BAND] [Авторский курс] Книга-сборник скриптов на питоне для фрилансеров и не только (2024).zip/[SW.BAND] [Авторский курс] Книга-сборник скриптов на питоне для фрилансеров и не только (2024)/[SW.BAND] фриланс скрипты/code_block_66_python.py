def start(update, context):
update.message.reply_text("Добро пожаловать! Чем
могу помочь?")
def handle_message(update, context):
user_message = update.message.text
response = f"Вы сказали: {user_message}"
update.message.reply_text(response)
def run_bot(token):
updater = Updater(token, use_context=True)
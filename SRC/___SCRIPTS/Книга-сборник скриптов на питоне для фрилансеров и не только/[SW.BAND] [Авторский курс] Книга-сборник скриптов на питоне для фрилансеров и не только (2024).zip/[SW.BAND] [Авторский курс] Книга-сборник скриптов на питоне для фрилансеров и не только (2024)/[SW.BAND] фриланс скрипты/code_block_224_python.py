url = f"https://api.github.com/users/{username}/repos"
response = requests.get(url)
if response.status_code == 200:
repos = response.json()
return [{"name": repo["name"], "url": repo["html_url"]} for
Параметры:
api_key (str): API-ключ для доступа к Freelancehunt.
project_id (int): ID проекта.
comment (str): Комментарий к предложению.
bid_amount (float): Сумма предложения.
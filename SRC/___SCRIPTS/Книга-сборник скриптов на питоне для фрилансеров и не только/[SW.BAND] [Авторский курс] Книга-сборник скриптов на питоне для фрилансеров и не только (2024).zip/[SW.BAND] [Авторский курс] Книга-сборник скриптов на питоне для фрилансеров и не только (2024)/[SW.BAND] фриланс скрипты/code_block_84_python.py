"PHONE": [{"VALUE": phone_number,
"VALUE_TYPE": "WORK"}]
}
}
response = requests.post(url, json=data)
if response.status_code == 200:
print("Лид успешно добавлен!")
else:
print("Ошибка:", response.json())
# Пример использования
add_lead_to_bitrix(
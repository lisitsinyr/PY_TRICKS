Код:
def get_client_info(api_key, client_id):
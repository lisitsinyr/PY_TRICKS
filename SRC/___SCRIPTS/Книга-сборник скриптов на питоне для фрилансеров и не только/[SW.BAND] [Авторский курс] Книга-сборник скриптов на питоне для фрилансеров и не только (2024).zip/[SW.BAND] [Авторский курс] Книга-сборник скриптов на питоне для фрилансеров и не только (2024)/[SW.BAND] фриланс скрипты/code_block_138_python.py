# Отправляем запрос GET
response = requests.get(url)
# Проверяем статус ответа
if response.status_code == 200:
users = response.json() # Декодируем JSON-ответ
for user in users:
print(f"Имя: {user['name']}, Email: {user['email']}")
else:
print('Ошибка при запросе данных!')
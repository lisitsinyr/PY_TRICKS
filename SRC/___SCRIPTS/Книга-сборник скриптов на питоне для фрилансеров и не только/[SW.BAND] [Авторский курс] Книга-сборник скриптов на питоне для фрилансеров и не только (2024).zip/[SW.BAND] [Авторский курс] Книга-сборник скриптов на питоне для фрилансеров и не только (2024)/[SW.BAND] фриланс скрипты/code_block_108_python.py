Код:
import socket
def scan_ports(host, ports):
for port in ports:
sock = socket.socket(socket.AF_INET,
socket.SOCK_STREAM)
sock.settimeout(1)
result = sock.connect_ex((host, port))
if result == 0:
print(f"Порт {port} открыт")
else:
print(f"Порт {port} закрыт")
sock.close()
# Пример использования
scan_ports("127.0.0.1", [22, 80, 443, 8080])
password = ''.join(random.choice(characters) for i in
range(length))
print(f"Сгенерированный пароль: {password}")
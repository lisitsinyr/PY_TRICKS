ServiceAccountCredentials.from_json_keyfile_name(credent
ials_file, scope)
client = gspread.authorize(creds)
sheet = client.open(sheet_name).sheet1
data = sheet.get_all_records()
for row in data:
print(row)
# Пример использования
read_google_sheet("credentials.json", "Test Sheet")
6.2. Интеграция с CRM-системами (AmoCRM, Bitrix24)
Описание:
from fpdf import FPDF
def create_pdf(client_name, services, output_file):
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)
pdf.cell(200, 10, txt="Коммерческое предложение",
ln=True, align='C')
pdf.ln(10)
pdf.cell(200, 10, txt=f"Уважаемый {client_name},",
ln=True)
pdf.multi_cell(0, 10, f"Мы предлагаем:
{services}")
pdf.output(output_file)
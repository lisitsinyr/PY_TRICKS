сегодня.")
while True:
schedule.run_pending()
time.sleep(1)
# Пример использования
schedule_reminders("your_telegram_bot_token",
"your_chat_id")
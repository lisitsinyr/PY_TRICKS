url = f"https://api.freelancehunt.com/v2/clients/{client_id}"
headers = {"Authorization": f"Bearer {api_key}"}
response = requests.get(url, headers=headers)
if response.status_code == 200:
client = response.json()["data"]
print(f"Имя клиента: {client['attributes']['name']}")
print(f"Рейтинг: {client['attributes']['rating']}")
else:
print(f"Ошибка: {response.status_code},
{response.text}")
# Пример использования
get_client_info("your_api_key", 789123)
params={"path": disk_path}
)
if response.status_code == 200:
upload_url = response.json()["href"]
with open(file_path, "rb") as f:
requests.put(upload_url, files={"file": f})
print(f"Файл загружен на Yandex.Disk: {disk_path}")
else:
print("Ошибка:", response.json())
# Пример использования
upload_to_yandex_disk("your_yandex_token", "example.txt",
"/example.txt")
Код:
import os
def replace_in_file(template_path, output_path,
replacements):
with open(template_path, 'r', encoding='utf-8') as file:
content = file.read()
for key, value in replacements.items():
content = content.replace(key, value)
with open(output_path, 'w', encoding='utf-8') as file:
file.write(content)
print(f"Договор сохранен в {output_path}")
# Пример использования
replacements = {"{CLIENT_NAME}": "Иван Иванов",
"{DATE}": "22.12.2024", "{AMOUNT}": "50000 руб."}
replace_in_file("template_contract.txt",
"contract_ivan_ivanov.txt", replacements)
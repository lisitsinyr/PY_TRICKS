Код:
import json
def check_access(user, resource):
with open("access_config.json", "r") as config_file:
access_data = json.load(config_file)
if user in access_data and resource in access_data[user]:
print(f"Доступ для {user} к {resource} разрешен.")
else:
print(f"Доступ для {user} к {resource} запрещен.")
# Пример файла access_config.json:
# {
# "admin": ["server", "database", "config"],
# "user123": ["server"]
# }
# Пример использования
check_access("admin", "database")
check_access("user123", "config")
Код:
import requests
from requests.auth import HTTPBasicAuth
def get_data_from_1c(api_url, username, password):
response = requests.get(api_url,
auth=HTTPBasicAuth(username, password))
if response.status_code == 200:
data = response.json()
for item in data['value']:
print(item)
else:
print("Ошибка:", response.status_code, response.text)
# Пример использования
get_data_from_1c(
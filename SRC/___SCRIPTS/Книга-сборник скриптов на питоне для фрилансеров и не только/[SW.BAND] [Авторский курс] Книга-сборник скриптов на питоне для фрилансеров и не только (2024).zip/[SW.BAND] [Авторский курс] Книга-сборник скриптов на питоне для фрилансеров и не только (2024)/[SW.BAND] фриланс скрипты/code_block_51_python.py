Код для генерации PDF:
from fpdf import FPDF
def generate_pdf_report(projects, output_file):
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)
pdf.cell(200, 10, txt="Отчет по проектам", ln=True,
align='C')
pdf.ln(10)
for project in projects:
pdf.cell(200, 10, txt=f"Проект: {project['name']}",
ln=True)
pdf.cell(200, 10, txt=f"Статус: {project['status']}",
ln=True)
pdf.cell(200, 10, txt=f"Бюджет: {project['budget']} руб.",
ln=True)
pdf.ln(5)
pdf.output(output_file)
print(f"Отчет сохранен в {output_file}")
# Пример использования
Код для скачивания и сортировки:
import os
import requests
def download_and_sort_files(url_list, download_folder):
if not os.path.exists(download_folder):
os.makedirs(download_folder)
for url in url_list:
filename = os.path.basename(url)
filepath = os.path.join(download_folder, filename)
response = requests.get(url)
with open(filepath, 'wb') as file:
file.write(response.content)
print(f"Скачан файл: {filename}")
# Сортировка по расширениям
for file in os.listdir(download_folder):
ext = os.path.splitext(file)[1][1:]
ext_folder = os.path.join(download_folder, ext)
if not os.path.exists(ext_folder):
os.makedirs(ext_folder)
os.rename(os.path.join(download_folder, file),
os.path.join(ext_folder, file))
print("Файлы успешно отсортированы!")
# Пример использования
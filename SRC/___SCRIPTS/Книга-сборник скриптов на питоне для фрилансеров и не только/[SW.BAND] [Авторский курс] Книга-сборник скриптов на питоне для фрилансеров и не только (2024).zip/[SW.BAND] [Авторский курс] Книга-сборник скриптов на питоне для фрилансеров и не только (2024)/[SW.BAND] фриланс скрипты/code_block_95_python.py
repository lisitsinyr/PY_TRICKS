)
''')
conn.commit()
conn.close()
print(f"База данных {db_name} создана.")
# Пример использования
create_sqlite_database("users.db")
Код для PostgreSQL:
import psycopg2
def create_postgresql_table(db_name, user, password, host,
port):
conn = psycopg2.connect(
Код для Telegram-бота:
from telegram import Bot, Update
from telegram.ext import Updater, CommandHandler,
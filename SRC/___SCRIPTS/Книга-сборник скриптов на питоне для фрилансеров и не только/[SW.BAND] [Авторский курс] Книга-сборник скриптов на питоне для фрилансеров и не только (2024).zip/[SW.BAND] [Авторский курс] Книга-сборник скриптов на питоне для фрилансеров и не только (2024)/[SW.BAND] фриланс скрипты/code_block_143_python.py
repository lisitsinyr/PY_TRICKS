# Отправляем запрос на сайт
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')
# Извлекаем цену товара
price = soup.find('span', {'class': 'price'}).text
# Условие для отправки уведомления
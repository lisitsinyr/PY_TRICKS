sia = SentimentIntensityAnalyzer()
for review in reviews:
sentiment_score = sia.polarity_scores(review)
sentiment = (
"Положительный" if sentiment_score["compound"] >
Код:
import pandas as pd
def analyze_data(file_path):
df = pd.read_excel(file_path)
total_sales = df["Сумма"].sum()
avg_sales = df["Сумма"].mean()
print(f"Общая сумма продаж: {total_sales}")
print(f"Средняя сумма продаж: {avg_sales}")
# Пример использования
analyze_data("corporate_data.xlsx")
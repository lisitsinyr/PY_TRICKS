Код для мониторинга:
import requests
from bs4 import BeautifulSoup
def monitor_website(url, element_selector):
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')
elements = soup.select(element_selector)
for i, element in enumerate(elements, 1):
print(f"{i}. {element.text.strip()}")
# Пример использования
monitor_website("https://example.com", ".product-title")
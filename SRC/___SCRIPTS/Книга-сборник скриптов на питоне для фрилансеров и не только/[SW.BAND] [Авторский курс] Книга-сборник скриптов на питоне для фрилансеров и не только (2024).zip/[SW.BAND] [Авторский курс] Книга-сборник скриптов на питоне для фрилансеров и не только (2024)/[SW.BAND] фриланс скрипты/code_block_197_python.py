Код:
def get_notifications(api_key):
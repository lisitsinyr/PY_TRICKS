Код:
def get_completed_orders(session, url):
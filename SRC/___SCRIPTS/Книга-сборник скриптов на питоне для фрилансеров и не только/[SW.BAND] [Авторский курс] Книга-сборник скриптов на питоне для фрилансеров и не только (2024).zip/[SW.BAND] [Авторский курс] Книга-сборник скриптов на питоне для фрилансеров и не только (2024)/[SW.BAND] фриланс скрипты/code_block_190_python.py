Код:
def send_bid(api_key, project_id, comment, bid_amount):
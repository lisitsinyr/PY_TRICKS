import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
# Загрузка необходимых данных (выполните один раз)
nltk.download("vader_lexicon")
def analyze_review_sentiment(reviews):
Код:
import paramiko
def upload_to_server(host, port, username, password,
local_file, remote_path):
transport = paramiko.Transport((host, port))
transport.connect(username=username,
password=password)
sftp = paramiko.SFTPClient.from_transport(transport)
sftp.put(local_file, remote_path)
print(f"Файл {local_file} загружен на сервер в
{remote_path}")
sftp.close()
transport.close()
# Пример использования
upload_to_server("your.server.com", 22, "user", "password",
"local_data.txt", "/remote/data.txt")
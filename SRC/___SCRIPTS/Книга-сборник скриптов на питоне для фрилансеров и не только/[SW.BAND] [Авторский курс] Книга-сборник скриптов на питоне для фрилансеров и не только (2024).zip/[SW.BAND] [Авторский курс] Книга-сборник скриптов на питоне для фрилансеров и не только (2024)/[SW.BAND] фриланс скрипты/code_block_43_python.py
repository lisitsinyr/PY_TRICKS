)
Код для работы с Google Sheets API:
import gspread
from oauth2client.service_account import
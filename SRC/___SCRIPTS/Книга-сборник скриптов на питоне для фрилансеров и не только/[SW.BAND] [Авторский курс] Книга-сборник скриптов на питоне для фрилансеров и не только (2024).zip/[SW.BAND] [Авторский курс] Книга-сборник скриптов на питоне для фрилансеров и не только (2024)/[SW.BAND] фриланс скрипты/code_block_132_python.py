import requests
from bs4 import BeautifulSoup
# Отправляем запрос на сайт
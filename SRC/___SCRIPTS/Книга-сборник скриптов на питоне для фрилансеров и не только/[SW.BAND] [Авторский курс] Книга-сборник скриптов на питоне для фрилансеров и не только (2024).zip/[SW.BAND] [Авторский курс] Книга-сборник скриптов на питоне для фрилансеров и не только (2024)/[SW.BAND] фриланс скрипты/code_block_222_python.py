Этот скрипт получает список ваших репозиториев из GitHub:
import requests
def fetch_github_repositories(username):
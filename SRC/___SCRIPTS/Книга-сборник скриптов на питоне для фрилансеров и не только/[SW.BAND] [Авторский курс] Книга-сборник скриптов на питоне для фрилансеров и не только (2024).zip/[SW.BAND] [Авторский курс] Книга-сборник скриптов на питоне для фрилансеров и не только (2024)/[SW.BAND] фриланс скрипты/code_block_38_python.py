import requests
from bs4 import BeautifulSoup
def parse_website(url, css_selector):
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')
items = soup.select(css_selector)
for item in items:
print(item.text.strip())
# Пример использования
parse_website("https://example.com", ".title")
2.2. Конвертация файлов (Excel в CSV, JSON в Excel).
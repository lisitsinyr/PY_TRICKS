Код:
import requests
def login_to_advego(email, password):
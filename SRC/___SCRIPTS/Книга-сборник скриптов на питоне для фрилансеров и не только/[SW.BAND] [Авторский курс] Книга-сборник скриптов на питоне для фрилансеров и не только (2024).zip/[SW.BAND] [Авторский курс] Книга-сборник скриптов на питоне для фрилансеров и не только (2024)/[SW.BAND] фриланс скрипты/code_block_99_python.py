Код:
import sqlite3
def execute_query(db_name, query, params=None):
conn = sqlite3.connect(db_name)
cursor = conn.cursor()
if params:
cursor.execute(query, params)
else:
cursor.execute(query)
conn.commit()
if query.strip().lower().startswith("select"):
results = cursor.fetchall()
for row in results:
print(row)
conn.close()
# Пример использования
execute_query("users.db", "INSERT INTO users (name,
email) VALUES (?, ?)", ("Иван Иванов",
"ivan@example.com"))
execute_query("users.db", "SELECT * FROM users")
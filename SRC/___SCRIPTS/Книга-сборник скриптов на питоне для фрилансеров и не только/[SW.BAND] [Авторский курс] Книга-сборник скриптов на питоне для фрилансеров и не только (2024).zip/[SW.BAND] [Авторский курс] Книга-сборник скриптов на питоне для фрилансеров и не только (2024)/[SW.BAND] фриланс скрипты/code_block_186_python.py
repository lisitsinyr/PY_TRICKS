response = session.get(url)
soup = BeautifulSoup(response.text, 'html.parser')
orders = soup.select(".completed-order-item")
for order in orders:
title = order.select_one(".order-title").text.strip()
date = order.select_one(".order-date").text.strip()
print(f"Заказ: {title}")
print(f"Дата выполнения: {date}\n")
# Пример использования
if session:
get_completed_orders(session,
"https://advego.com/completed_orders/")
Советы:
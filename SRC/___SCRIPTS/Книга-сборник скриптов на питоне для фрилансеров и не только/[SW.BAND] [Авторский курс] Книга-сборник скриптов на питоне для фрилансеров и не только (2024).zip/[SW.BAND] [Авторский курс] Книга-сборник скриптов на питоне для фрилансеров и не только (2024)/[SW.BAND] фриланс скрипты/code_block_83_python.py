Код:
import requests
def add_lead_to_bitrix(webhook_url, lead_name,
phone_number):
url = f"{webhook_url}crm.lead.add"
data = {
"fields": {
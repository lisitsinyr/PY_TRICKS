import pandas as pd
import matplotlib.pyplot as plt
def plot_excel(file_path, x_column, y_column):
data = pd.read_excel(file_path)
plt.plot(data[x_column], data[y_column], marker='o')
plt.title(f"{y_column} vs {x_column}")
plt.xlabel(x_column)
plt.ylabel(y_column)
plt.grid()
plt.show()
# Пример использования
plot_excel("sales_data.xlsx", "Дата", "Продажи")
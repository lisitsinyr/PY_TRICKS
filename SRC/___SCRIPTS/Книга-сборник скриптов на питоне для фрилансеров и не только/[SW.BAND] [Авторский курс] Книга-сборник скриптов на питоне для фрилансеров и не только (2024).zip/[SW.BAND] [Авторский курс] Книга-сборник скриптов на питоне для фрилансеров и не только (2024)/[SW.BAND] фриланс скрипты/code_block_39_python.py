import pandas as pd
def excel_to_csv(input_file, output_file):
df = pd.read_excel(input_file)
df.to_csv(output_file, index=False)
print(f"Excel файл успешно преобразован в CSV:
{output_file}")
# Пример использования
excel_to_csv("data.xlsx", "data.csv")
2.3. Работа с API для анализа данных (например, API
Google или OpenAI)
Описание:
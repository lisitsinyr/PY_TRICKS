import requests
def get_currency_rate(currency_code):
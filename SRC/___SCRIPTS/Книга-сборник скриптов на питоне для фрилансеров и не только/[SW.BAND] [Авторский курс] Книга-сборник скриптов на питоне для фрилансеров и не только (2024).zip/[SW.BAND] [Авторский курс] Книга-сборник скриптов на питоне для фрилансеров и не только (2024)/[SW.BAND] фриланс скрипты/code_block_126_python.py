Код:
import csv
def add_transaction(file_path, transaction_type, amount,
description):
with open(file_path, "a", newline="") as file:
writer = csv.writer(file)
writer.writerow([transaction_type, amount, description])
print("Транзакция добавлена.")
def analyze_finances(file_path):
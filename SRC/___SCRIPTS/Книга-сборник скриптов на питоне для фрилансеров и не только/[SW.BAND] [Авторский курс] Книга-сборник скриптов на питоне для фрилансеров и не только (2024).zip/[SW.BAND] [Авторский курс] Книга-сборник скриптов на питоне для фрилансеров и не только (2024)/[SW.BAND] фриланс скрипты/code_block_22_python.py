import schedule
import time
def task_reminder():
print("Напоминание: Выполните задачу!")
schedule.every().day.at("10:00").do(task_reminder)
while True:
schedule.run_pending()
time.sleep(1)
headers = {"Authorization": f"Bearer {api_key}"}
response = requests.get(url, headers=headers)
if response.status_code == 200:
projects = response.json()["data"]
for project in projects:
print(f"Название: {project['attributes']['name']}")
print(f"Описание:
{project['attributes']['description']}\n")
else:
print(f"Ошибка: {response.status_code},
{response.text}")
# Пример использования
get_projects("your_api_key")
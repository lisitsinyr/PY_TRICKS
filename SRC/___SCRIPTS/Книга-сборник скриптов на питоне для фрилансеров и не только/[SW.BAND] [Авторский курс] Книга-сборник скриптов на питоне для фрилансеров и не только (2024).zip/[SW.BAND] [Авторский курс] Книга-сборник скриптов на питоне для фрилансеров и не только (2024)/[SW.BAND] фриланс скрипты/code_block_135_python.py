from selenium import webdriver
from selenium.webdriver.common.by import By
# Настройка WebDriver
driver = webdriver.Chrome()
# Открываем страницу
driver.get('https://example.com')
# Извлекаем заголовок страницы
title = driver.find_element(By.TAG_NAME, 'h1').text
print(title)
# Закрываем браузер
driver.quit()
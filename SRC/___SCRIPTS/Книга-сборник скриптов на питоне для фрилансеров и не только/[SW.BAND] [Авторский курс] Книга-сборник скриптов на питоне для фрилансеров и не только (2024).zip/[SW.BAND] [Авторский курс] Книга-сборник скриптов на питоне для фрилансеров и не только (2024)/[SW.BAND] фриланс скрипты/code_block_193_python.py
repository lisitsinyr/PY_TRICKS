}
response = requests.post(url, json=data,
headers=headers)
if response.status_code == 201:
print("Предложение успешно отправлено!")
else:
print(f"Ошибка: {response.status_code},
{response.text}")
# Пример использования
send_bid("your_api_key", 123456, "Здравствуйте! Я готов
выполнить этот проект.", 500)
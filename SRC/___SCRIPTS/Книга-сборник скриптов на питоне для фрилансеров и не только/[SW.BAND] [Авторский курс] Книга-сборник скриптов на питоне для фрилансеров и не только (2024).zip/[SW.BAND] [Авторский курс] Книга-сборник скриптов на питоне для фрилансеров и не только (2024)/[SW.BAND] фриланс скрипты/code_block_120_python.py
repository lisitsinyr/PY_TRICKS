Код:
from telegram import Bot
import schedule
import time
def send_reminder(token, chat_id, message):
bot = Bot(token=token)
bot.send_message(chat_id=chat_id, text=message)
def schedule_reminders(token, chat_id):
schedule.every().day.at("09:00").do(send_reminder,
import requests
# URL для получения списка вакансий на Upwork
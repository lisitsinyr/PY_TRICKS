Код:
import os
import shutil
from zipfile import ZipFile
def rename_files(directory, prefix):
for i, filename in enumerate(os.listdir(directory), 1):
ext = os.path.splitext(filename)[1]
new_name = f"{prefix}_{i}{ext}"
os.rename(os.path.join(directory, filename),
os.path.join(directory, new_name))
print("Файлы переименованы.")
def sort_files(directory):
for filename in os.listdir(directory):
ext = os.path.splitext(filename)[1][1:]
if ext:
ext_folder = os.path.join(directory, ext)
if not os.path.exists(ext_folder):
os.makedirs(ext_folder)
shutil.move(os.path.join(directory, filename),
os.path.join(ext_folder, filename))
print("Файлы отсортированы по типам.")
def archive_files(directory, archive_name):
with ZipFile(archive_name, 'w') as zipf:
for foldername, subfolders, filenames in
os.walk(directory):
for filename in filenames:
filepath = os.path.join(foldername, filename)
zipf.write(filepath, os.path.relpath(filepath,
directory))
print(f"Все файлы заархивированы в {archive_name}.")
# Пример использования
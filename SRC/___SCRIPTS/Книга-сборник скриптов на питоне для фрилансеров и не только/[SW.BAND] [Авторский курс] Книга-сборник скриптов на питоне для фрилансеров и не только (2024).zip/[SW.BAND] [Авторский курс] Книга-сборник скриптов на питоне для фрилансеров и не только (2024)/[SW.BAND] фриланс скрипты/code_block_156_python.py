}
# Отправка запроса
response = requests.get(url, headers=headers)
if response.status_code == 200:
orders = response.json()
for order in orders['data']:
print(f"Заказ: {order['title']}, Статус: {order['status']}")
else:
print('Ошибка при получении заказов!')
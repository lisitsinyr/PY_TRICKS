import requests
from bs4 import BeautifulSoup
def collect_reviews(url, css_selector):
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')
reviews = soup.select(css_selector)
for review in reviews:
print(review.text)
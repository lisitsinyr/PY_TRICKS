data = {"text": text}
headers = {"User-Agent": "Mozilla/5.0"}
response = requests.post(url, data=data,
headers=headers)
if response.status_code == 200:
print("Текст отправлен на проверку. Результаты
можно посмотреть в вашем аккаунте.")
else:
print(f"Ошибка: {response.status_code}")
# Пример использования
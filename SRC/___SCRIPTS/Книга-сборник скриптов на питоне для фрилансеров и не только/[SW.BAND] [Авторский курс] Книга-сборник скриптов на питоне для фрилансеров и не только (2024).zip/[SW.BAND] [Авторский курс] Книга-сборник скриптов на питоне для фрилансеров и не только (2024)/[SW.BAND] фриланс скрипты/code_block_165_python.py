headers = {"Authorization": f"Bearer {api_key}"}
response = requests.get(url, headers=headers)
if response.status_code == 200:
orders = response.json()
for order in orders.get("data", []):
print(f"ID заказа: {order['id']}")
print(f"Статус: {order['status']}")
print(f"Сумма: {order['amount']} {order['currency']}\n")
else:
print(f"Ошибка: {response.status_code},
{response.text}")
# Пример использования
get_fiverr_orders("your_api_key")
Советы по интеграции:
1. Получение API-ключей:
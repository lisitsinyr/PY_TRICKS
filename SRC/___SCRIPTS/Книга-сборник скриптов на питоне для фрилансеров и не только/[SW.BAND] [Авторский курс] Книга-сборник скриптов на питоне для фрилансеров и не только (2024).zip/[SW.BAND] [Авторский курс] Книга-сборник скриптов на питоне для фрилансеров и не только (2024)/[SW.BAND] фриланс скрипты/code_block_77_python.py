Код для объединения PDF-файлов:
from PyPDF2 import PdfMerger
def merge_pdfs(pdf_list, output_file):
merger = PdfMerger()
for pdf in pdf_list:
merger.append(pdf)
merger.write(output_file)
merger.close()
print(f"PDF-файлы объединены в {output_file}")
# Пример использования
merge_pdfs(["file1.pdf", "file2.pdf"], "merged.pdf")
Код для разбиения PDF-файла:
from PyPDF2 import PdfReader, PdfWriter
def split_pdf(input_file, output_folder):
reader = PdfReader(input_file)
for i, page in enumerate(reader.pages):
writer = PdfWriter()
writer.add_page(page)
output_file = f"{output_folder}/page_{i + 1}.pdf"
with open(output_file, 'wb') as output_pdf:
writer.write(output_pdf)
print(f"Страница {i + 1} сохранена в {output_file}")
# Пример использования
split_pdf("big_document.pdf", "output_pages")
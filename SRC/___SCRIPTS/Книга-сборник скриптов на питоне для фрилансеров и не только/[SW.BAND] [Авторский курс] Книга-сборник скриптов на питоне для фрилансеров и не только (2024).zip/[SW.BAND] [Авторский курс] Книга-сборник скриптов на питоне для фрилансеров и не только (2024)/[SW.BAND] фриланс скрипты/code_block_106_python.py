def decrypt_message(encrypted_message):
key = load_key()
fernet = Fernet(key)
decrypted = fernet.decrypt(encrypted_message)
print(f"Расшифрованное сообщение:
{decrypted.decode()}")
# Пример использования
generate_key()
encrypted_msg = encrypt_message("Это
конфиденциальная информация.")
decrypt_message(encrypted_msg)
projects = fetch_github_repositories(username)
return render_template("portfolio.html", projects=projects)
if __name__ == "__main__":
app.run(debug=True)
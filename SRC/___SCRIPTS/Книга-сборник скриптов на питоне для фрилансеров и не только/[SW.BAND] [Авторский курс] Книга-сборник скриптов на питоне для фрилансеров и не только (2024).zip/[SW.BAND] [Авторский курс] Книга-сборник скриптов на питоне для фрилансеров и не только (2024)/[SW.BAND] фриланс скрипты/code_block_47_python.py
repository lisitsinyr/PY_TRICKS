Код для удаления дубликатов:
import pandas as pd
def remove_duplicates(input_file, output_file):
df = pd.read_csv(input_file)
df_cleaned = df.drop_duplicates()
df_cleaned.to_csv(output_file, index=False)
print(f"Дубликаты удалены. Результат сохранен в:
{output_file}")
# Пример использования
remove_duplicates("data_with_duplicates.csv",
"cleaned_data.csv")
Код для поиска дубликатов по определенной колонке:
def find_duplicates(input_file, column_name):
df = pd.read_csv(input_file)
duplicates = df[df.duplicated([column_name])]
print("Найдены дубликаты:")
print(duplicates)
# Пример использования
find_duplicates("data.csv", "email")
fetch_github_repositories("your_github_username")
for repo in repositories:
print(repo)
Код для Google Drive:
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.oauth2.service_account import Credentials
def upload_to_google_drive(credentials_file, file_path,
folder_id):
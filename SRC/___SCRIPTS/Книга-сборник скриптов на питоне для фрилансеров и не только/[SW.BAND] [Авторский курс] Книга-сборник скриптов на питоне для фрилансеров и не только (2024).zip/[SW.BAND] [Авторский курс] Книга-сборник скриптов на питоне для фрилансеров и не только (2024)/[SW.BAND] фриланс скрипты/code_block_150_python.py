headers = {'Content-Type': 'application/json'}
# Отправка запроса для получения данных о времени
response = requests.get(url, auth=(api_token, 'api_token'),
headers=headers)
if response.status_code == 200:
time_entries = response.json()
for entry in time_entries:
print(f"Задача: {entry['description']}, Время:
{entry['duration']} сек.")
else:
print('Ошибка при получении данных!')
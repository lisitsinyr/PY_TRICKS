Код:
import requests
def check_text_uniqueness(text):
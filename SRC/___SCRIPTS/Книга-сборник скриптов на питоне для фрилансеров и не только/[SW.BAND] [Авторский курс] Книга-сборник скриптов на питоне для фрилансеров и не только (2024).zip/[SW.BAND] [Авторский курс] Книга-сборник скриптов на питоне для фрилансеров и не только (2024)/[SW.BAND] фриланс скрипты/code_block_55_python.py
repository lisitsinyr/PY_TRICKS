Код для прогнозирования:
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
def predict_sales(file_path):
data = pd.read_excel(file_path)
X = data["Месяц"].values.reshape(-1, 1) # Признаки
(месяцы)
Пример автоматического заполнения формы:
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
# Настройка WebDriver
driver = webdriver.Chrome()
# Открываем страницу с формой
driver.get('https://example.com/contact')
# Заполняем поля формы
name_field = driver.find_element(By.NAME, 'name')
name_field.send_keys('John Doe')
email_field = driver.find_element(By.NAME, 'email')
email_field.send_keys('johndoe@example.com')
message_field = driver.find_element(By.NAME, 'message')
message_field.send_keys('Hello, this is a test message.')
# Отправляем форму
submit_button = driver.find_element(By.NAME, 'submit')
submit_button.click()
# Закрываем браузер
driver.quit()
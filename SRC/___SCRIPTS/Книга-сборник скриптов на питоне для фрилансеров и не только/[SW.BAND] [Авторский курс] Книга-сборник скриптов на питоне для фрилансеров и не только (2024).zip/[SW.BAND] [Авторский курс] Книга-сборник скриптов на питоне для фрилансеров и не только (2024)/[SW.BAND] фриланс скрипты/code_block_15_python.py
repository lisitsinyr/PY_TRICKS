with smtplib.SMTP('smtp.gmail.com', 587) as server:
server.starttls()
server.login(sender, password)
server.send_message(msg)
print("Письмо отправлено!")
Код для отправки HTML-письма:
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
def send_html_email(sender_email, sender_password,
recipient_email, subject, html_content):
# Формируем письмо
msg = MIMEMultipart("alternative")
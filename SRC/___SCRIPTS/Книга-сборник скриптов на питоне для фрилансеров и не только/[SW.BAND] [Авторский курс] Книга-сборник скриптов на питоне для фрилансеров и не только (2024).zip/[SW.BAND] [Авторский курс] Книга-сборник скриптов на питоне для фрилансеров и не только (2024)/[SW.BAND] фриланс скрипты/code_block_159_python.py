Пример кода для получения вакансий:
import requests
def get_upwork_jobs(api_key, keywords):
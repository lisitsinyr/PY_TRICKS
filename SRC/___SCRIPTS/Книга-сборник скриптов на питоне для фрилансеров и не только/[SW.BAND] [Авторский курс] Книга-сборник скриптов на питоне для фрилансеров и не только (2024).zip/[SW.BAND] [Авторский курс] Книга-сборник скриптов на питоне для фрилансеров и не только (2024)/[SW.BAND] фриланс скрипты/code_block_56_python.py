значения (продажи)
# Обучение модели
model = LinearRegression()
model.fit(X, y)
# Прогнозирование на следующие месяцы
future_months = [[i] for i in range(max(data["Месяц"]) + 1,
max(data["Месяц"]) + 6)]
predictions = model.predict(future_months)
# Вывод результатов
print("Прогноз продаж на следующие месяцы:")
for month, sales in zip(future_months, predictions):
print(f"Месяц {month[0]}: {sales:.2f} руб.")
# Построение графика
plt.scatter(X, y, color="blue", label="Фактические
данные")
plt.plot(future_months, predictions, color="red",
label="Прогноз")
plt.xlabel("Месяц")
plt.ylabel("Продажи")
plt.legend()
plt.show()
# Пример использования
predict_sales("sales_data.xlsx")
Пример данных в Excel (sales_data.xlsx):
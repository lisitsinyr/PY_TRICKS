Код для работы с OpenAI API:
import openai
def analyze_text(api_key, prompt):
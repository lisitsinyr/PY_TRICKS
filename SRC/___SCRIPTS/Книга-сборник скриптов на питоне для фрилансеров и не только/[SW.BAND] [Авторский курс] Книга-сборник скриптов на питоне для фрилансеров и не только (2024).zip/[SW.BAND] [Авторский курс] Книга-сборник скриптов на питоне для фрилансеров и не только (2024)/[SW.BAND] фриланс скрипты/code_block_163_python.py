Пример кода для получения данных о заказах:
import requests
def get_fiverr_orders(api_key):
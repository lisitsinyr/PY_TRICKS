def save_password(user, password):
with open("passwords.txt", "a") as file:
file.write(f"{user}: {password}\n")
print("Пароль сохранен.")
# Пример использования
user_password = generate_password()
save_password("user123", user_password)
import smtplib
from email.mime.text import MIMEText
def send_email(sender, password, recipient, subject, body):
msg = MIMEText(body)
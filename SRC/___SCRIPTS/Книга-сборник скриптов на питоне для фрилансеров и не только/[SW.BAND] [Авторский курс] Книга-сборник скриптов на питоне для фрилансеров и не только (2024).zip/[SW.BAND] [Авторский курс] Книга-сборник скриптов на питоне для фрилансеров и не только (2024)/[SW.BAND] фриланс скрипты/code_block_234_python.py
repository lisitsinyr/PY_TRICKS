<title>Портфолио</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.project { margin-bottom: 15px; }
.project a { text-decoration: none; color: #007BFF; }
</style>
</head>
<body>
<h1>Мои проекты</h1>
<ul>
{% for project in projects %}
<li class="project">
<a href="{{ project.url }}" target="_blank">{{
project.name }}</a>
</li>
{% endfor %}
</ul>
</body>
</html>
response = requests.get(url)
# Используем BeautifulSoup для парсинга HTML
soup = BeautifulSoup(response.text, 'html.parser')
# Извлекаем все ссылки на странице
links = soup.find_all('a')
# Выводим все ссылки
for link in links:
print(link.get('href'))
Пример с Selenium:
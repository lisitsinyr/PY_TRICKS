Параметры:
api_key (str): API-ключ для доступа к Freelancehunt.
client_id (int): ID клиента.
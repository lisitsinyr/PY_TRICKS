import requests
from bs4 import BeautifulSoup
def collect_reviews(url, css_selector):
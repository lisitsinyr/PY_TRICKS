Credentials.from_service_account_file(credentials_file)
service = build("drive", "v3", credentials=creds)
file_metadata = {"name": file_path.split("/")[-1], "parents":
[folder_id]}
media = MediaFileUpload(file_path, resumable=True)
file = service.files().create(body=file_metadata,
media_body=media, fields="id").execute()
print(f"Файл загружен в Google Drive, ID: {file.get('id')}")
# Пример использования
upload_to_google_drive("credentials.json", "example.txt",
"your_folder_id")
Код для Yandex.Disk:
import requests
def upload_to_yandex_disk(token, file_path, disk_path):
headers = {"Authorization": f"OAuth {token}"}
response = requests.get(
# Отправляем запрос на сайт
response = requests.get(url)
# Парсим страницу
soup = BeautifulSoup(response.text, 'html.parser')
# Извлекаем информацию о ценах и услугах
services = soup.find_all('div', class_='service')
for service in services:
name = service.find('h3').text
price = service.find('span', class_='price').text
print(f"Услуга: {name}, Цена: {price}")
response = requests.get(url)
if response.status_code == 200:
print(f"Курс {currency_code}: {response.text}")
else:
print("Ошибка получения курса.")
# Пример использования
get_currency_rate("USD")
проекты:
from flask import Flask, render_template
import requests
app = Flask(__name__)
def fetch_github_repositories(username):
url = f"https://api.github.com/users/{username}/repos"
response = requests.get(url)
if response.status_code == 200:
repos = response.json()
return [{"name": repo["name"], "url": repo["html_url"]} for
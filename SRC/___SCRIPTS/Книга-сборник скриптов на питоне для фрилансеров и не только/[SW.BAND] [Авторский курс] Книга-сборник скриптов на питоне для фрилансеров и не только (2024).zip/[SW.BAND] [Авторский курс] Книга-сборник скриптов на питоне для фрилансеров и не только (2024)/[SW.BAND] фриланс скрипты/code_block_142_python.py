with smtplib.SMTP('smtp.example.com') as server:
server.login('your_email@example.com',
'your_password')
server.sendmail(msg['From'], [msg['To']],
msg.as_string())
# URL страницы с товаром
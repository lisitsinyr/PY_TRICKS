headers = {"Authorization": f"Bearer {api_key}"}
response = requests.get(url, headers=headers)
if response.status_code == 200:
notifications = response.json()["data"]
for notification in notifications:
print(f"Тип: {notification['attributes']['type']}")
print(f"Сообщение:
{notification['attributes']['message']}\n")
else:
print(f"Ошибка: {response.status_code},
{response.text}")
# Пример использования
get_notifications("your_api_key")
Советы по использованию API Freelancehunt:
1. Получение API-ключа: